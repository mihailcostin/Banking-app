package com.wallet.servlet;

import com.wallet.db.DbUtils;
import com.wallet.pojo.User;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/signin")
public class SigninServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        User user = DbUtils.getUserByUsernameAndPassword(username, password);
        if (user == null) {
            response.sendRedirect("signin.jsp?error=Invalid username or password");
            return;
        }

        user.getEmail();
        request.getSession().setAttribute("user", user);
        response.sendRedirect("welcome.jsp"); // Sau orice pagină de succes dorești
    }
}
