package com.wallet.servlet;

import com.wallet.db.DbUtils;
import com.wallet.pojo.SavingsAccount;
import com.wallet.pojo.User;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/savings")
public class SavingsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User user = (User) request.getSession().getAttribute("user");
        if (user == null) {
            response.sendRedirect("signin.jsp");
            return;
        }

        String action = request.getParameter("action");
        if ("create".equals(action)) {
            double amount = Double.parseDouble(request.getParameter("amount"));
            String depositDate = request.getParameter("depositDate");

            if (DbUtils.createSavingsAccount(user.getId(), amount, depositDate)) {
                response.sendRedirect("savings.jsp?success=Account created successfully");
            } else {
                response.sendRedirect("savings.jsp?error=Failed to create account");
            }
        } else if ("view".equals(action)) {
            List<SavingsAccount> accounts = DbUtils.getSavingsAccounts(user.getId());
            request.setAttribute("accounts", accounts);
            request.getRequestDispatcher("savings.jsp").forward(request, response);
        }
    }
}
